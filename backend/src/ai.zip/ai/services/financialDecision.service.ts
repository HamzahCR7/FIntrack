export interface PurchaseRequest {
  amount?: number;
  category?: string;
  description?: string;
  targetMonths?: number;
}

export class FinancialDecisionService {
  evaluateAffordability(purchase: PurchaseRequest, context: Record<string, any>) {
    const overview = context.overview || {};
    const cashFlow = context.cashFlow || {};
    const income = Number(cashFlow.inflow || overview.totalIncome || 0);
    const expenses = Number(cashFlow.outflow || overview.totalExpenses || 0);
    const surplus = Number((income - expenses).toFixed(2));
    const balance = Number(overview.totalBalance || 0);
    const amount = purchase.amount;
    const safeSingleSpend = Math.max(0, Math.round(Math.max(surplus, 0) * 0.1));

    return {
      ...purchase,
      income,
      expenses,
      monthlySurplus: surplus,
      currentBalance: balance,
      safeSingleSpend,
      affordable: amount === undefined ? undefined : amount <= safeSingleSpend && amount <= balance,
      remainingBalance: amount === undefined ? undefined : Number((balance - amount).toFixed(2)),
    };
  }

  evaluateScenario(amount: number | undefined, context: Record<string, any>) {
    const cashFlow = context.cashFlow || {};
    const income = Number(cashFlow.inflow || context.overview?.totalIncome || 0);
    const expenses = Number(cashFlow.outflow || context.overview?.totalExpenses || 0);
    const spend = amount || 0;
    return {
      amount,
      currentMonthlySavings: Number((income - expenses).toFixed(2)),
      projectedMonthlySavings: Number((income - expenses - spend).toFixed(2)),
      balanceAfterSpend: context.overview?.totalBalance === undefined
        ? undefined
        : Number((context.overview.totalBalance - spend).toFixed(2)),
    };
  }
}