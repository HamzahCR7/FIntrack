export interface AIQueryRequest {
  query: string;
  contextHistory?: Array<{ sender: 'user' | 'assistant'; text: string }>;
}

export interface AIToolCall {
  toolName: string;
  toolParams?: Record<string, any>;
}

export interface AIOrchestrationPlan {
  intent: string;
  level: 1 | 2 | 3 | 4; // 1: Facts, 2: Analysis, 3: Insights, 4: Guidance
  toolCalls: AIToolCall[];
  capability?: string;
  entities?: {
    category?: string;
    amount?: number;
    date?: string;
    description?: string;
    targetMonths?: number;
    changeAmount?: number;
    frequency?: string;
  };
  requiredContext?: string[];
  clarification?: string;
}

export interface AIQueryResponse {
  query: string;
  intent: string;
  capability?: string;
  toolUsed: string;
  toolCallsExecuted: AIToolCall[];
  toolParameters?: Record<string, any>;
  data: any;
  answer: string;
  suggestedFollowUps?: string[];
}

export interface IAIProvider {
  processQuery(request: AIQueryRequest): Promise<AIOrchestrationPlan>;
}
