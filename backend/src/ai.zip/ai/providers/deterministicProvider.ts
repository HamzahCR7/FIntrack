import { IAIProvider, AIQueryRequest, AIOrchestrationPlan } from './aiProvider.interface';
import { prisma } from '../../config/prisma';
import { isDynamicMatch } from '../tools/financialToolRegistry';

export function parseAmount(query: string): number | undefined {
  const normalized = query.toLowerCase().replace(/,/g, '');
  const lakh = normalized.match(/(\d+(?:\.\d+)?)\s*(?:lakh|lakhs|lac|lacs)/);
  if (lakh) return Number(lakh[1]) * 100000;
  const thousand = normalized.match(/(\d+(?:\.\d+)?)\s*k\b/);
  if (thousand) return Number(thousand[1]) * 1000;
  const amount = normalized.match(/(?:₹|rs\.?|inr)\s*(\d+(?:\.\d+)?)/i) || normalized.match(/\b(\d{3,8})\b/);
  return amount ? Number(amount[1]) : undefined;
}

function parseTargetAmountAndItem(query: string): { targetAmount?: number; itemName?: string; targetMonths?: number } {
  const q = query.toLowerCase();
  let targetAmount: number | undefined;
  let itemName: string | undefined;

  // Amount parsing
  const lakhMatch = q.match(/(\d+(?:\.\d+)?)\s*(?:lakh|lakhs|lac|lacs)/i);
  if (lakhMatch) {
    targetAmount = parseFloat(lakhMatch[1]) * 100000;
  } else {
    const kMatch = q.match(/(\d+(?:\.\d+)?)\s*k\b/i);
    if (kMatch) {
      targetAmount = parseFloat(kMatch[1]) * 1000;
    } else {
      const numMatch =
        q.match(/(?:of|for|costing|costs|worth|price of|amount|in|rs|₹|\b)\s*([1-9]\d{3,7})\b/i) ||
        q.match(/\b([1-9]\d{3,7})\b/);
      if (numMatch) {
        targetAmount = parseFloat(numMatch[1].replace(/,/g, ''));
      }
    }
  }

  // Item parsing
  const itemKeywords = [
    'laptop',
    'mobile',
    'phone',
    'car',
    'bike',
    'tv',
    'ac',
    'house',
    'flat',
    'trip',
    'watch',
    'camera',
    'iphone',
    'macbook',
    'ipad',
    'playstation',
    'ps5',
    'vehicle',
    'gold',
  ];
  for (const item of itemKeywords) {
    if (q.includes(item)) {
      itemName = item;
      break;
    }
  }

  if (!itemName) {
    const buyMatch = q.match(
      /(?:buy|purchase|get|afford)\s+(?:a|an|the)?\s*([a-z0-9\s]+?)(?:\s+of|\s+for|\s+costing|\s+worth|\s+around|\s+in|\s*,|\s*\.|\s*$)/i
    );
    if (buyMatch && buyMatch[1]) {
      const candidate = buyMatch[1].trim();
      if (candidate.length > 1 && !['a', 'an', 'the', 'some', 'any'].includes(candidate)) {
        itemName = candidate;
      }
    }
  }

  // Timeframe / months parsing
  let targetMonths: number | undefined;
  const monthMatch = q.match(/(?:in|within|over|after|for|during)?\s*(\d+)\s*(?:month|months|mth|mths)\b/i);
  if (monthMatch && monthMatch[1]) {
    targetMonths = parseInt(monthMatch[1], 10);
  } else {
    const yearMatch = q.match(/(?:in|within|over|after|for|during)?\s*(\d+)\s*(?:year|years|yr|yrs)\b/i);
    if (yearMatch && yearMatch[1]) {
      targetMonths = parseInt(yearMatch[1], 10) * 12;
    }
  }

  return { targetAmount, itemName, targetMonths };
}

function editDistance(first: string, second: string): number {
  const previous = Array.from({ length: second.length + 1 }, (_, index) => index);

  for (let firstIndex = 1; firstIndex <= first.length; firstIndex++) {
    const current = [firstIndex];
    for (let secondIndex = 1; secondIndex <= second.length; secondIndex++) {
      const substitutionCost = first[firstIndex - 1] === second[secondIndex - 1] ? 0 : 1;
      current[secondIndex] = Math.min(
        current[secondIndex - 1] + 1,
        previous[secondIndex] + 1,
        previous[secondIndex - 1] + substitutionCost
      );
    }
    previous.splice(0, previous.length, ...current);
  }

  return previous[second.length];
}

const CATEGORY_ALIASES: Record<string, string[]> = {
  'Utilities': ['utility', 'utilities', 'utilies', 'electricity', 'water', 'gas', 'wifi', 'internet', 'power', 'bill', 'bills', 'light bill', 'current bill', 'utility bill', 'utility bills'],
  'Food & Dining': ['food', 'dining', 'restaurant', 'restaurants', 'eating', 'eat', 'fooding', 'dinner', 'lunch', 'breakfast'],
  'Groceries': ['grocery', 'groceries', 'goceries', 'kirana', 'supermarket', 'zepto', 'blinkit', 'instamart'],
  'Rent & Housing': ['rent', 'housing', 'house', 'home rent', 'flat rent', 'accommodation', 'room rent'],
  'Transport': ['transport', 'transportation', 'travel', 'fuel', 'petrol', 'diesel', 'cab', 'cabs', 'auto', 'taxi', 'commute', 'uber', 'ola'],
  'Shopping': ['shopping', 'clothes', 'clothing', 'apparel', 'garments', 'amazon', 'flipkart', 'myntra'],
  'Entertainment': ['entertainment', 'movie', 'movies', 'cinema', 'theatre', 'gaming', 'games', 'fun', 'netflix', 'spotify'],
  'Health & Medical': ['health', 'medical', 'medicine', 'medicines', 'doctor', 'hospital', 'pharmacy', 'clinic', 'medical bill'],
  'Education Loan': ['education', 'loan', 'tuition', 'college', 'school', 'fees', 'fee', 'student loan'],
  'Salary & Income': ['salary', 'income', 'earnings', 'paycheck', 'wages'],
  'Pocket Allowance': ['pocket money', 'pocket allowance', 'allowance'],
  'Miscellaneous': ['misc', 'miscellaneous', 'other', 'others'],
};

function matchCategory(term: string, dbCategories: { name: string }[] = []): string | null {
  const normTerm = term.toLowerCase().trim();
  if (!normTerm || normTerm.length < 2) return null;

  // 1. Check direct category aliases
  for (const [catName, aliases] of Object.entries(CATEGORY_ALIASES)) {
    for (const alias of aliases) {
      if (normTerm === alias || normTerm.includes(alias) || alias.includes(normTerm)) {
        return catName;
      }
    }
  }

  // 2. Check DB categories
  for (const cat of dbCategories) {
    const normCat = cat.name.toLowerCase();
    if (normCat === normTerm || normCat.includes(normTerm) || normTerm.includes(normCat)) {
      return cat.name;
    }
  }

  // 3. Fuzzy edit distance matching against aliases
  for (const [catName, aliases] of Object.entries(CATEGORY_ALIASES)) {
    for (const alias of aliases) {
      if (alias.length >= 4 && normTerm.length >= 4) {
        const allowed = alias.length > 7 ? 2 : 1;
        if (editDistance(alias, normTerm) <= allowed) {
          return catName;
        }
      }
    }
  }

  // 4. Fuzzy edit distance matching against DB category names
  for (const cat of dbCategories) {
    const normCat = cat.name.toLowerCase();
    if (normCat.length >= 4 && normTerm.length >= 4) {
      const allowed = normCat.length > 7 ? 2 : 1;
      if (editDistance(normCat, normTerm) <= allowed) {
        return cat.name;
      }
    }
  }

  return null;
}

export class DeterministicAIProvider implements IAIProvider {
  async processQuery(request: AIQueryRequest): Promise<AIOrchestrationPlan> {
    const rawQ = request.query.trim();
    const q = rawQ.toLowerCase();

    const isGreeting = /^(hello|hi|hey|thanks|thank you|good morning|good evening)\b/.test(q);
    if (isGreeting) {
      return { intent: 'GENERAL_CONVERSATION', level: 1, capability: 'CONVERSATION', toolCalls: [] };
    }

    const isFinancialKnowledge =
      q.includes('compound interest') || q.includes('what is sip') || q.includes('explain sip') ||
      q.includes('difference between credit and debit');
    if (isFinancialKnowledge) {
      return { intent: 'FINANCIAL_KNOWLEDGE', level: 1, capability: 'FINANCIAL_KNOWLEDGE', toolCalls: [] };
    }

    if (/how much.*(?:spent|spend|expenses?).*this month/.test(q)) {
      return {
        intent: 'FINANCIAL_DATA_QUERY',
        level: 1,
        capability: 'MONTHLY_EXPENSES',
        requiredContext: ['CASH_FLOW'],
        toolCalls: [{ toolName: 'getMonthlyExpenses' }],
      };
    }

    if (q.includes('why did i spend more') || q.includes('why spending increased')) {
      return {
        intent: 'FINANCIAL_ANALYSIS',
        level: 2,
        capability: 'SPENDING_TREND_ANALYSIS',
        requiredContext: ['CASH_FLOW', 'CATEGORY_SPENDING', 'SPENDING_TREND'],
        toolCalls: [
          { toolName: 'getMonthlyExpenses' },
          { toolName: 'comparePeriods' },
          { toolName: 'getCategoryAnalysis' },
        ],
      };
    }

    const amount = parseAmount(rawQ);
    const isScenario = q.includes('what if') || q.includes('what happens if');
    if (isScenario) {
      return {
        intent: 'FINANCIAL_SCENARIO',
        level: 2,
        capability: 'SCENARIO_ANALYSIS',
        entities: { amount, description: rawQ },
        requiredContext: ['FINANCIAL_OVERVIEW', 'CASH_FLOW'],
        toolCalls: [
          { toolName: 'getFinancialOverview' },
          { toolName: 'getCashFlowAnalysis' },
        ],
      };
    }

    const isDecision =
      q.includes('should i') || q.includes('can i afford') || q.includes('is it a good idea') ||
      q.includes('is it okay') || q.includes('is it fine') || q.includes('is it financially') ||
      q.includes('do i have enough') || q.includes('would') || q.includes('should i buy');
    if (isDecision) {
      const hasPurchase = amount !== undefined || /buy|purchase|spend|dinner|restaurant|meal|trip|phone|laptop|shopping|subscription|go out|eat out/.test(q);
      if (!hasPurchase) {
        return {
          intent: 'FINANCIAL_DECISION',
          level: 4,
          capability: 'PURCHASE_AFFORDABILITY',
          clarification: 'What are you considering buying, and approximately how much does it cost?',
          toolCalls: [],
        };
      }

      const category = /restaurant|dinner|meal|eat out|food/.test(q) ? 'Food & Dining' : undefined;
      return {
        intent: 'FINANCIAL_DECISION',
        level: 4,
        capability: 'PURCHASE_AFFORDABILITY',
        entities: { amount, category, description: rawQ },
        requiredContext: ['FINANCIAL_OVERVIEW', 'CASH_FLOW', ...(category ? ['CATEGORY_SPENDING'] : []), 'UPCOMING_OBLIGATIONS'],
        toolCalls: [
          { toolName: 'getFinancialOverview' },
          { toolName: 'getCashFlowAnalysis' },
          ...(category ? [{ toolName: 'getExpensesByCategory', toolParams: { categoryName: category } }] : []),
          { toolName: 'getUpcomingObligations' },
        ],
      };
    }

    // Fetch DB categories & merchants for dynamic intent matching
    let dbCategories: { name: string }[] = [];
    let dbMerchants: { merchant: string }[] = [];
    try {
      dbCategories = await prisma.category.findMany({ select: { name: true } });
      const rawTx = await prisma.transaction.findMany({ select: { merchant: true } });
      dbMerchants = rawTx.filter((t): t is { merchant: string } => Boolean(t.merchant));
    } catch (e) {
      // Ignore DB lookup errors in provider
    }

    // 0. Discretionary Spending Decision Queries ("is it good idea to go to restaurant today?", "should I eat out tonight?")
    const isDecisionQuery =
      q.includes('good idea') ||
      q.includes('great idea') ||
      q.includes('bad idea') ||
      q.includes('should i') ||
      q.includes('should we') ||
      q.includes('is it okay') ||
      q.includes('is it fine') ||
      q.includes('is it safe') ||
      q.includes('is it wise') ||
      q.includes('can i go') ||
      q.includes('can i eat') ||
      q.includes('can i treat') ||
      q.includes('worth going') ||
      q.includes('worth spending');

    if (isDecisionQuery) {
      const catMatch = matchCategory(q, dbCategories);
      const activityMatch = q.match(/(?:go to|eat at|visit|order|eat|buy|spend on)\s+([a-z0-9&\s-]+)/i);
      const itemName = activityMatch ? activityMatch[1].trim() : 'outings';

      return {
        intent: 'DISCRETIONARY_DECISION',
        level: 4,
        toolCalls: [
          { toolName: 'getFinancialOverview', toolParams: { itemName, categoryName: catMatch || 'Food & Dining' } },
          { toolName: 'getCashFlowAnalysis' },
          { toolName: 'getCategoryAnalysis' },
          { toolName: 'getExpensesByCategory', toolParams: { categoryName: catMatch || 'Food & Dining' } },
        ],
      };
    }

    // 1. Affordability & Purchase Feasibility Queries ("buy a laptop", "can I afford", "how should I buy", "savings trend to buy...")
    if (
      q.includes('afford') ||
      q.includes('buy') ||
      q.includes('purchase') ||
      q.includes('is it affordable') ||
      q.includes('can i spend') ||
      q.includes('can we afford') ||
      q.includes('considering my income') ||
      q.includes('how i shall buy') ||
      q.includes('how to buy') ||
      q.includes('how should i buy') ||
      q.includes('savings trend') ||
      q.includes('savings trends')
    ) {
      const { targetAmount, itemName, targetMonths } = parseTargetAmountAndItem(rawQ);
      return {
        intent: 'AFFORDABILITY_ANALYSIS',
        level: 4,
        toolCalls: [
          { toolName: 'getFinancialOverview', toolParams: { targetAmount, itemName, targetMonths } },
          { toolName: 'getCashFlowAnalysis', toolParams: { targetAmount, itemName, targetMonths } },
        ],
      };
    }

    const asksForSavingsAmount = q.includes('how much') || q.includes('should i save') || q.includes('need to save');
    const asksAboutNextMonth = q.includes('next month') || q.includes('next-month');
    const asksForSavingsRate = q.includes('savings rate') || q.includes('savings target') || /\d+\s*%/.test(q);
    if (q.includes('save') && asksForSavingsAmount && (asksAboutNextMonth || asksForSavingsRate)) {
      return {
        intent: 'SAVINGS_TARGET_PROJECTION',
        level: 2,
        toolCalls: [{ toolName: 'getSavingsAnalysis' }],
      };
    }

    // 1. Cost Reduction / Savings Cuts / Spending Advice Queries ("where do I cut", "which area I should spend less", "save 30000 where to cut")
    if (
      q.includes('cut') ||
      q.includes('less') ||
      q.includes('save') ||
      q.includes('reduce') ||
      q.includes('where to') ||
      q.includes('which area') ||
      q.includes('spending tip') ||
      q.includes('financial advice') ||
      q.includes('recommendation') ||
      q.includes('suggestion') ||
      q.includes('financial health') ||
      q.includes('how am i doing') ||
      q.includes('improve savings')
    ) {
      return {
        intent: 'FINANCIAL_ADVICE',
        level: 4,
        toolCalls: [
          { toolName: 'getFinancialOverview' },
          { toolName: 'getCashFlowAnalysis' },
          { toolName: 'getCategoryAnalysis' },
          { toolName: 'getCreditCardAnalysis' },
          { toolName: 'getRecurringExpenseAnalysis' },
          { toolName: 'getDebtsSummary' },
        ],
      };
    }

    // 2. Peak & Top Spending Queries ("When did I spend the most", "where did money go", "highest expenses")
    if (
      q.includes('most') ||
      q.includes('highest') ||
      q.includes('biggest') ||
      q.includes('largest') ||
      q.includes('top spend') ||
      q.includes('maximum') ||
      q.includes('where did most of my money go') ||
      q.includes('when did i spend') ||
      q.includes('when i spend')
    ) {
      return {
        intent: 'SPENDING_INCREASE_ANALYSIS',
        level: 2,
        toolCalls: [
          { toolName: 'getMonthlyExpenses' },
          { toolName: 'getCategoryAnalysis' },
          { toolName: 'getLargeTransactions', toolParams: { limit: 5 } },
          { toolName: 'comparePeriods' },
        ],
      };
    }

    // 1. Scenario Analysis (What-If questions)
    if (q.includes('what if') || q.includes('what happens if') || q.includes('if i reduce') || q.includes('if i save') || q.includes('when will i reach')) {
      if (q.includes('reach') || q.includes('goal') || q.includes('lakh') || q.includes('target')) {
        let targetAmount = 500000;
        if (q.includes('5 lakh') || q.includes('5lakh')) targetAmount = 500000;
        else if (q.includes('10 lakh')) targetAmount = 1000000;

        return {
          intent: 'SCENARIO_SAVINGS_GOAL',
          level: 4,
          toolCalls: [
            { toolName: 'runScenarioAnalysis', toolParams: { type: 'SAVINGS_GOAL_HORIZON', params: { targetAmount } } },
            { toolName: 'getSavingsAnalysis' },
          ],
        };
      }

      return {
        intent: 'SCENARIO_REDUCE_SPEND',
        level: 4,
        toolCalls: [
          { toolName: 'runScenarioAnalysis', toolParams: { type: 'REDUCE_CATEGORY_SPEND', params: { categoryName: 'Food & Dining', reductionPercent: 20 } } },
          { toolName: 'getCategoryAnalysis' },
        ],
      };
    }

    // 2. Spending Increase & Why Queries (Multi-tool analysis)
    if (q.includes('why did i spend more') || q.includes('why spending increased') || q.includes('spending increase') || q.includes('where did most of my money go')) {
      return {
        intent: 'SPENDING_INCREASE_ANALYSIS',
        level: 2,
        toolCalls: [
          { toolName: 'getMonthlyExpenses' },
          { toolName: 'comparePeriods' },
          { toolName: 'getCategoryAnalysis' },
          { toolName: 'getLargeTransactions', toolParams: { limit: 5 } },
        ],
      };
    }

    // 3. Level 4 Financial Advice / Savings Optimization / Cost Reduction Queries (Multi-tool)
    if (
      q.includes('save more') ||
      q.includes('how can i save') ||
      q.includes('how to save') ||
      q.includes('financial advice') ||
      q.includes('cut cost') ||
      q.includes('reduce expense') ||
      q.includes('spending tip') ||
      q.includes('financial tip') ||
      q.includes('save money') ||
      q.includes('advice') ||
      q.includes('tip') ||
      q.includes('recommendation') ||
      q.includes('suggestion') ||
      q.includes('how am i doing') ||
      q.includes('financial health') ||
      q.includes('improve savings')
    ) {
      return {
        intent: 'FINANCIAL_ADVICE',
        level: 4,
        toolCalls: [
          { toolName: 'getFinancialOverview' },
          { toolName: 'getCashFlowAnalysis' },
          { toolName: 'getCategoryAnalysis' },
          { toolName: 'getCreditCardAnalysis' },
          { toolName: 'getRecurringExpenseAnalysis' },
          { toolName: 'getDebtsSummary' },
        ],
      };
    }

    const hasSpendingQuestion =
      q.includes('how much') ||
      q.includes('total') ||
      q.includes('spent') ||
      q.includes('spend') ||
      q.includes('cost') ||
      q.includes('costs') ||
      q.includes('paid') ||
      q.includes('expense') ||
      q.includes('expenses');

    if (hasSpendingQuestion) {
      const spendTargetMatch =
        q.match(/(?:how much|total|amount|what|show|get)\s*(?:money|cash|did i|did|do|i|was|is)?\s*(?:spent|spend|expenses?|spending|cost|costs|paid)?\s*(?:on|at|for|with|in|to|from|by)\s+([a-z0-9&\s-]+)/i) ||
        q.match(/(?:spent|spend|expenses?|spending|paid)\s+(?:on|for|in|with|at|to|from)\s+([a-z0-9&\s-]+)/i) ||
        q.match(/(?:money|cash)\s+(?:given to|lent to|paid to|sent to|spent on|spent with|for|to|with|on)\s+([a-z0-9&\s-]+)/i);

      if (spendTargetMatch && spendTargetMatch[1]) {
        const entityName = spendTargetMatch[1]
          .replace(/\b(this month|last month|today|yesterday|this year|last year|amount|total|money|cash|please|can you|did i|did|do|i|was|is|my|the|a|an|overall|all)\b/gi, '')
          .trim();
        if (entityName.length > 1) {
          // 1. First check if entity is a Category (exact, alias, or fuzzy editDistance e.g. 'utilies' -> 'Utilities')
          const catMatch = matchCategory(entityName, dbCategories);
          if (catMatch) {
            return {
              intent: 'EXPENSE_BY_CATEGORY',
              level: 1,
              toolCalls: [{ toolName: 'getExpensesByCategory', toolParams: { categoryName: catMatch } }],
            };
          }

          // 2. Check if entity matches a person in debts
          try {
            const knownPersons = await prisma.debt.findMany({ select: { personName: true } });
            const knownPerson = knownPersons.find((p) => isDynamicMatch(p.personName, entityName));
            if (knownPerson) {
              return {
                intent: 'SEARCH_FINANCIAL_DATA',
                level: 1,
                toolCalls: [{ toolName: 'searchFinancialData', toolParams: { searchTerm: knownPerson.personName } }],
              };
            }
          } catch (e) {}

          // 3. Fallback to merchant/entity spending with entityName
          return {
            intent: 'MERCHANT_SPENDING',
            level: 1,
            toolCalls: [{ toolName: 'getMerchantSpending', toolParams: { merchantName: entityName } }],
          };
        }
      }
    }

    // Check if the query itself contains any category name/alias (e.g., 'utilities', 'food', 'groceries', 'rent')
    const generalCatMatch = matchCategory(q, dbCategories);
    if (generalCatMatch && hasSpendingQuestion) {
      return {
        intent: 'EXPENSE_BY_CATEGORY',
        level: 1,
        toolCalls: [{ toolName: 'getExpensesByCategory', toolParams: { categoryName: generalCatMatch } }],
      };
    }

    // 4. Entity / Person Search Prepositions (e.g. "given to Rahul", "lent to Hammad", "paid to Zepto", "money for Abbu")
    const searchMatch =
      q.match(/(?:given to|lent to|borrowed from|paid to|sent to|received from|transfer to|money to|money for)\s+([a-z0-9\s]+)/i) ||
      q.match(/(?:money given|who owes|money owed|debt for)\s+([a-z0-9\s]+)/i);

    if (searchMatch && searchMatch[1]) {
      const candidateTerm = searchMatch[1].replace(/(this month|last month|today|yesterday|money|total|amount|please|can you)/gi, '').trim();
      if (candidateTerm.length > 1) {
        return {
          intent: 'SEARCH_FINANCIAL_DATA',
          level: 1,
          toolCalls: [{ toolName: 'searchFinancialData', toolParams: { searchTerm: candidateTerm } }],
        };
      }
    }

    // 5. Database Entity Lookup (Persons / Merchants / Descriptions / Notes / Categories / Accounts)
    try {
      const knownPersons = await prisma.debt.findMany({ select: { personName: true, notes: true } });
      for (const p of knownPersons) {
        if ((p.personName && isDynamicMatch(p.personName, q)) || (p.notes && isDynamicMatch(p.notes, q))) {
          return {
            intent: 'SEARCH_FINANCIAL_DATA',
            level: 1,
            toolCalls: [{ toolName: 'searchFinancialData', toolParams: { searchTerm: p.personName || q } }],
          };
        }
      }

      const knownTransactions = await prisma.transaction.findMany({
        select: { merchant: true, description: true, category: { select: { name: true } }, sourceAccount: { select: { name: true } } },
      });
      for (const t of knownTransactions) {
        const fields = [t.merchant, t.description, t.category?.name, t.sourceAccount?.name];
        const matchedField = fields.find((f) => isDynamicMatch(f, q));
        if (matchedField) {
          const asksForAmount = q.includes('how much') || q.includes('spent') || q.includes('spend') || q.includes('expense') || q.includes('total') || q.includes('cost');
          if (asksForAmount) {
            return {
              intent: 'MERCHANT_SPENDING',
              level: 1,
              toolCalls: [{ toolName: 'getMerchantSpending', toolParams: { merchantName: matchedField } }],
            };
          }
          return {
            intent: 'SEARCH_FINANCIAL_DATA',
            level: 1,
            toolCalls: [{ toolName: 'searchFinancialData', toolParams: { searchTerm: matchedField } }],
          };
        }
      }
    } catch (e) {
      // Ignore DB lookup errors in provider
    }

    // 6. Category Queries
    if (q.includes('food') || q.includes('dining') || q.includes('eating') || q.includes('restaurant')) {
      return {
        intent: 'EXPENSE_BY_CATEGORY',
        level: 1,
        toolCalls: [{ toolName: 'getExpensesByCategory', toolParams: { categoryName: 'Food & Dining' } }],
      };
    }
    if (q.includes('grocery') || q.includes('groceries') || q.includes('zepto') || q.includes('blinkit')) {
      return {
        intent: 'EXPENSE_BY_CATEGORY',
        level: 1,
        toolCalls: [{ toolName: 'getExpensesByCategory', toolParams: { categoryName: 'Groceries' } }],
      };
    }
    if (q.includes('education') || q.includes('loan') || q.includes('college') || q.includes('tuition')) {
      return {
        intent: 'EXPENSE_BY_CATEGORY',
        level: 1,
        toolCalls: [{ toolName: 'getExpensesByCategory', toolParams: { categoryName: 'Education Loan' } }],
      };
    }
    if (q.includes('salary') || q.includes('income') || q.includes('earned')) {
      return {
        intent: 'MONTHLY_INCOME',
        level: 1,
        toolCalls: [{ toolName: 'getMonthlyIncome', toolParams: {} }],
      };
    }

    // 7. Credit Card Queries
    if (q.includes('credit card') || q.includes('credit-card') || q.includes('card') || q.includes('my zone')) {
      if (q.includes('food') || q.includes('dining') || q.includes('merchant')) {
        return {
          intent: 'EXPENSE_BY_ACCOUNT_AND_CATEGORY',
          level: 1,
          toolCalls: [{ toolName: 'getExpensesByAccount', toolParams: { accountNameStr: 'Credit Card', categoryNameStr: 'Food' } }],
        };
      }
      return {
        intent: 'CREDIT_CARD_SUMMARY',
        level: 1,
        toolCalls: [{ toolName: 'getCreditCardOutstanding', toolParams: {} }],
      };
    }

    // 8. Payment Method Queries
    if (q.includes('upi') || q.includes('gpay') || q.includes('phonepe')) {
      return {
        intent: 'EXPENSE_BY_PAYMENT_METHOD',
        level: 1,
        toolCalls: [{ toolName: 'getExpensesByPaymentMethod', toolParams: { paymentMethodStr: 'UPI' } }],
      };
    }
    if (q.includes('cash')) {
      return {
        intent: 'EXPENSE_BY_PAYMENT_METHOD',
        level: 1,
        toolCalls: [{ toolName: 'getExpensesByPaymentMethod', toolParams: { paymentMethodStr: 'CASH' } }],
      };
    }

    // 9. Subscriptions & Recurring
    if (q.includes('subscription') || q.includes('recurring') || q.includes('netflix') || q.includes('spotify')) {
      if (q.includes('next month') || q.includes('upcoming') || q.includes('due')) {
        return {
          intent: 'UPCOMING_SUBSCRIPTIONS',
          level: 1,
          toolCalls: [{ toolName: 'getUpcomingSubscriptions', toolParams: { daysAhead: 30 } }],
        };
      }
      return {
        intent: 'SUBSCRIPTION_SUMMARY',
        level: 2,
        toolCalls: [
          { toolName: 'getSubscriptionSummary', toolParams: {} },
          { toolName: 'getRecurringExpenseAnalysis', toolParams: {} },
        ],
      };
    }

    // 10. Debt / Money Owed / Borrowed
    if (q.includes('owe') || q.includes('borrowed') || q.includes('lent') || q.includes('debt') || q.includes('loan')) {
      return {
        intent: 'DEBT_SUMMARY',
        level: 1,
        toolCalls: [{ toolName: 'getDebtsSummary', toolParams: {} }],
      };
    }

    // 11. Comparison & Trends
    if (q.includes('compare') || q.includes('comparison') || q.includes('versus') || q.includes('vs')) {
      return {
        intent: 'COMPARE_PERIODS',
        level: 2,
        toolCalls: [
          { toolName: 'comparePeriods', toolParams: {} },
          { toolName: 'getCategoryAnalysis', toolParams: {} },
        ],
      };
    }
    if (q.includes('trend') || q.includes('history') || q.includes('months')) {
      return {
        intent: 'SPENDING_TREND',
        level: 2,
        toolCalls: [{ toolName: 'getSpendingTrend', toolParams: {} }],
      };
    }

    // 12. General Summaries
    if (q.includes('spend') || q.includes('spent') || q.includes('expense')) {
      return {
        intent: 'MONTHLY_EXPENSES',
        level: 1,
        toolCalls: [{ toolName: 'getMonthlyExpenses', toolParams: {} }],
      };
    }

    if (q.includes('balance') || q.includes('net worth') || q.includes('saved') || q.includes('money')) {
      return {
        intent: 'CURRENT_BALANCE',
        level: 1,
        toolCalls: [{ toolName: 'getCurrentBalance', toolParams: {} }],
      };
    }

    // General Natural Language Fallback: Always return comprehensive financial advice & live ledger facts
    return {
      intent: 'FINANCIAL_ADVICE',
      level: 4,
      toolCalls: [
        { toolName: 'getFinancialOverview' },
        { toolName: 'getCashFlowAnalysis' },
        { toolName: 'getCategoryAnalysis' },
        { toolName: 'getCreditCardAnalysis' },
        { toolName: 'getRecurringExpenseAnalysis' },
      ],
    };
  }
}
