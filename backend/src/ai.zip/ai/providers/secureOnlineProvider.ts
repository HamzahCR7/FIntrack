import { z } from 'zod';
import { IAIProvider, AIQueryRequest, AIOrchestrationPlan } from './aiProvider.interface';
import { DeterministicAIProvider } from './deterministicProvider';
import { ExternalAIRequest, inspectExternalAIPayload, validateExternalAIRequest } from './externalAIPrivacyGuard';

/**
 * 🔒 SECURE ONLINE AI PROVIDER (OpenAI / Gemini Interchangeable)
 * 
 * SECURITY & ARCHITECTURE COMPLIANCE POLICIES:
 * 1. UNTRUSTED LLM OUTPUT: All external model outputs are treated as completely untrusted input.
 * 2. STRICT SCHEMA VALIDATION: External JSON responses are validated via Zod schemas before execution.
 * 3. INTENT ALLOWLIST: Only explicitly approved intent codes are permitted.
 * 4. TOOL ALLOWLIST: Only registered, pre-approved backend tool names can be invoked.
 * 5. TOOL PARAMETER VALIDATION: Tool arguments are sanitized to block prototype pollution & injection.
 * 6. NO ARBITRARY TOOL EXECUTION: Dynamic execution of unlisted functions or scripts is impossible.
 * 7. ZERO FINANCIAL DATA EXPOSURE: No database rows, balances, transactions, or PII leave the server.
 *    Only sanitized query text is transmitted for intent classification.
 * 8. SENSITIVE-DATA EXPOSURE POLICY: API keys, bearer tokens, and secrets are strictly server-side.
 * 9. NO SECRETS OR PROMPTS IN LOGS: Logs scrub sensitive details, credentials, and full payloads.
 * 10. ENV CONFIGURABILITY: Models and timeout limits are configured via environment variables.
 * 11. LOCAL DETERMINISTIC CALCULATIONS: All financial math/aggregations run inside backend engines.
 * 12. PROVIDER ABSTRACTION: Interchangeable OpenAI/Gemini support with local fallback.
 */

const ALLOWED_INTENTS = new Set([
  'FINANCIAL_ADVICE',
  'AFFORDABILITY_ANALYSIS',
  'DISCRETIONARY_DECISION',
  'SPENDING_INCREASE_ANALYSIS',
  'MONTHLY_EXPENSES',
  'EXPENSE_BY_CATEGORY',
  'DEBT_SUMMARY',
  'CREDIT_CARD_SUMMARY',
  'MONTHLY_INCOME',
  'SCENARIO_REDUCE_SPEND',
  'SCENARIO_SAVINGS_GOAL',
  'SAVINGS_TARGET_PROJECTION',
  'SEARCH_FINANCIAL_DATA',
  'CURRENT_BALANCE',
  'COMPARE_PERIODS',
  'SPENDING_TREND',
  'SUBSCRIPTION_SUMMARY',
  'UPCOMING_SUBSCRIPTIONS',
  'EXPENSE_BY_PAYMENT_METHOD',
  'EXPENSE_BY_ACCOUNT_AND_CATEGORY',
  'MERCHANT_SPENDING',
  'GENERAL_CONVERSATION',
  'FINANCIAL_KNOWLEDGE',
  'FINANCIAL_DATA_QUERY',
  'FINANCIAL_ANALYSIS',
  'FINANCIAL_DECISION',
  'FINANCIAL_SCENARIO',
  'FINANCIAL_CALCULATION',
  'FINANCIAL_GOAL',
]);

const ALLOWED_TOOLS = new Set([
  'getFinancialOverview',
  'getCashFlowAnalysis',
  'getCategoryAnalysis',
  'getMonthlyExpenses',
  'getMonthlyIncome',
  'getLargeTransactions',
  'comparePeriods',
  'getCreditCardAnalysis',
  'getRecurringExpenseAnalysis',
  'getDebtsSummary',
  'runScenarioAnalysis',
  'getExpensesByCategory',
  'getExpensesByPaymentMethod',
  'getExpensesByAccount',
  'getCreditCardOutstanding',
  'getSubscriptionSummary',
  'getUpcomingSubscriptions',
  'searchFinancialData',
  'getSavingsAnalysis',
  'getAccountAnalysis',
  'getSpendingAnomalies',
  'getMerchantAnalysis',
  'getMerchantSpending',
  'getFinancialProfile',
  'getCurrentBalance',
  'getNetWorth',
]);

const ALLOWED_TOOL_NAMES = [...ALLOWED_TOOLS];

// Strict Zod Validation Schema for LLM Output
const ToolCallSchema = z.object({
  toolName: z.string().refine((val) => ALLOWED_TOOLS.has(val), {
    message: 'Requested tool name is not in the allowed tools list',
  }),
  toolParams: z.record(z.union([z.string(), z.number(), z.boolean()])).optional(),
});

const OrchestrationPlanSchema = z.object({
  intent: z.string().refine((val) => ALLOWED_INTENTS.has(val), {
    message: 'Requested intent is not in the allowed intents list',
  }),
  level: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4)]).default(4),
  toolCalls: z.array(ToolCallSchema).max(10),
  capability: z.string().optional(),
  entities: z.record(z.union([z.string(), z.number(), z.boolean(), z.null()])).optional(),
  requiredContext: z.array(z.string()).max(10).optional(),
  clarification: z.string().max(300).nullable().optional(),
});

export class SecureOnlineAIProvider implements IAIProvider {
  private fallbackProvider: DeterministicAIProvider;

  constructor() {
    this.fallbackProvider = new DeterministicAIProvider();
  }

  private getTimeoutMs(): number {
    const envVal = parseInt(process.env.AI_TIMEOUT_MS || '', 10);
    return !isNaN(envVal) && envVal > 0 ? envVal : 6000;
  }

  private getOpenAIModel(): string {
    return process.env.OPENAI_MODEL || 'gpt-4o-mini';
  }

  private getGeminiModel(): string {
    return process.env.GEMINI_MODEL || 'gemini-1.5-flash';
  }

  async processQuery(request: AIQueryRequest): Promise<AIOrchestrationPlan> {
    const openaiKey = process.env.OPENAI_API_KEY;
    const geminiKey = process.env.GEMINI_API_KEY;
    const deterministicPlan = await this.fallbackProvider.processQuery(request);

    if (!openaiKey && !geminiKey) {
      // Graceful local fallback when no external API keys are set
      return deterministicPlan;
    }

    try {
      if (openaiKey) {
        return await this.callOpenAI(request.query, openaiKey);
      } else if (geminiKey) {
        return await this.callGemini(request.query, geminiKey);
      }
    } catch {
      // Scrubbed log message: No prompts, keys, or query content exposed in logs
      console.warn('[SecureOnlineAIProvider] External LLM call failed or timed out. Falling back to local engine.');
      return this.fallbackProvider.processQuery(request);
    }

    return this.fallbackProvider.processQuery(request);
  }

  private async callOpenAI(query: string, apiKey: string): Promise<AIOrchestrationPlan> {
    const sanitizedQuery = this.sanitizeInput(query);
    const timeoutMs = this.getTimeoutMs();
    const externalRequest: ExternalAIRequest = {
      query: sanitizedQuery,
      allowedTools: ALLOWED_TOOL_NAMES,
    };
    validateExternalAIRequest(externalRequest);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const systemPrompt = `You are a privacy-first financial conversation planner. Analyze the user's question and output a JSON plan. You receive only the question, never financial records. Choose a broad capability; local application code gathers facts and performs all calculations.

Available Tools:
- getFinancialOverview
- getCashFlowAnalysis
- getCategoryAnalysis
- getMonthlyExpenses
- getMonthlyIncome
- getLargeTransactions
- comparePeriods
- getCreditCardAnalysis
- getRecurringExpenseAnalysis
- getDebtsSummary
- runScenarioAnalysis
- getExpensesByCategory
- getSavingsAnalysis
- getMerchantSpending

For questions asking how much to save next month to reach a savings percentage or savings-rate goal, use intent SAVINGS_TARGET_PROJECTION and tool getSavingsAnalysis.
For questions asking how much was spent on a category or utility/groceries/food (or misspellings like utilies), use intent EXPENSE_BY_CATEGORY and tool getExpensesByCategory with parameter categoryName.
For questions asking how much was spent at a named merchant, use intent MERCHANT_SPENDING and tool getMerchantSpending.

For purchase decisions use capability PURCHASE_AFFORDABILITY and entities {category, amount, description}. For what-if questions use SCENARIO_ANALYSIS. If purchase details are missing, return clarification and no tool calls. Greetings and general financial education require no tool calls.
Respond ONLY with valid JSON in this exact structure:
{
  "intent": "GENERAL_CONVERSATION" | "FINANCIAL_KNOWLEDGE" | "FINANCIAL_DATA_QUERY" | "FINANCIAL_ANALYSIS" | "FINANCIAL_DECISION" | "FINANCIAL_SCENARIO" | "FINANCIAL_CALCULATION" | "FINANCIAL_GOAL",
  "capability": "CONVERSATION" | "FINANCIAL_KNOWLEDGE" | "PURCHASE_AFFORDABILITY" | "SCENARIO_ANALYSIS",
  "entities": { "category": "DINING", "amount": null, "description": "restaurant" },
  "requiredContext": ["FINANCIAL_OVERVIEW", "CASH_FLOW"],
  "clarification": null,
  "level": 1 | 2 | 3 | 4,
  "toolCalls": []
}`;

    try {
      const body = {
        model: this.getOpenAIModel(),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: externalRequest.query },
        ],
        response_format: { type: 'json_object' },
        temperature: 0.1,
      };
      inspectExternalAIPayload(body);

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!response.ok) {
        throw new Error(`OpenAI API returned status ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) throw new Error('Empty response from OpenAI');

      // Treat raw LLM response as UNTRUSTED and validate with Zod
      const rawParsed = JSON.parse(content);
      const validatedPlan = OrchestrationPlanSchema.parse(rawParsed);

      return {
        intent: validatedPlan.intent,
        level: validatedPlan.level as 1 | 2 | 3 | 4,
        toolCalls: validatedPlan.toolCalls.map((tc) => ({
          toolName: tc.toolName,
          toolParams: this.sanitizeToolParams(tc.toolParams),
        })),
        capability: validatedPlan.capability,
        entities: validatedPlan.entities as AIOrchestrationPlan['entities'],
        requiredContext: validatedPlan.requiredContext,
        clarification: validatedPlan.clarification || undefined,
      };
    } catch (err) {
      clearTimeout(timeout);
      throw err;
    }
  }

  private async callGemini(query: string, apiKey: string): Promise<AIOrchestrationPlan> {
    const sanitizedQuery = this.sanitizeInput(query);
    const timeoutMs = this.getTimeoutMs();
    const externalRequest: ExternalAIRequest = {
      query: sanitizedQuery,
      allowedTools: ALLOWED_TOOL_NAMES,
    };
    validateExternalAIRequest(externalRequest);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const prompt = `Analyze this query: "${externalRequest.query}".
  Output JSON with broad intent, capability, entities, requiredContext, clarification, level (1-4), and toolCalls (array of { toolName, toolParams }). Never request or infer sensitive financial records. Local code performs financial calculations.
  For questions asking how much to save next month to reach a savings percentage or savings-rate goal, use intent SAVINGS_TARGET_PROJECTION and tool getSavingsAnalysis.
  For questions asking how much was spent on a category or utility/groceries/food (or misspellings like utilies), use intent EXPENSE_BY_CATEGORY and tool getExpensesByCategory with parameter categoryName.
  For questions asking how much was spent at a named merchant, use intent MERCHANT_SPENDING and tool getMerchantSpending.
  Allowed Tool Names: getFinancialOverview, getCashFlowAnalysis, getCategoryAnalysis, getMonthlyExpenses, comparePeriods, getLargeTransactions, getCreditCardAnalysis, getDebtsSummary, getSavingsAnalysis, getExpensesByCategory, getMerchantSpending.`;

    try {
      const modelName = this.getGeminiModel();
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`;
      const body = {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: 'application/json' },
      };
      inspectExternalAIPayload(body);

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      clearTimeout(timeout);
      if (!response.ok) throw new Error(`Gemini API returned status ${response.status}`);

      const data = await response.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!text) throw new Error('Empty text from Gemini');

      // Treat raw LLM response as UNTRUSTED and validate with Zod
      const rawParsed = JSON.parse(text);
      const validatedPlan = OrchestrationPlanSchema.parse(rawParsed);

      return {
        intent: validatedPlan.intent,
        level: validatedPlan.level as 1 | 2 | 3 | 4,
        toolCalls: validatedPlan.toolCalls.map((tc) => ({
          toolName: tc.toolName,
          toolParams: this.sanitizeToolParams(tc.toolParams),
        })),
        capability: validatedPlan.capability,
        entities: validatedPlan.entities as AIOrchestrationPlan['entities'],
        requiredContext: validatedPlan.requiredContext,
        clarification: validatedPlan.clarification || undefined,
      };
    } catch (err) {
      clearTimeout(timeout);
      throw err;
    }
  }

  private sanitizeInput(input: string): string {
    // Strip control characters & enforce length cap to protect token budget
    return input.replace(/[\x00-\x1F\x7F]/g, '').slice(0, 500);
  }

  private sanitizeToolParams(params?: Record<string, any>): Record<string, any> {
    if (!params || typeof params !== 'object') return {};
    const clean: Record<string, any> = {};
    const forbiddenKeys = new Set(['__proto__', 'constructor', 'prototype']);

    for (const [key, val] of Object.entries(params)) {
      if (forbiddenKeys.has(key)) continue;
      if (typeof val === 'string') {
        clean[key] = val.replace(/[\x00-\x1F\x7F]/g, '').slice(0, 100);
      } else if (typeof val === 'number' && Number.isFinite(val)) {
        clean[key] = val;
      } else if (typeof val === 'boolean') {
        clean[key] = val;
      }
    }
    return clean;
  }
}

